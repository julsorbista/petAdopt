package com.example.adoptp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class showCat extends AppCompatActivity {

    private static final String PREFS_NAME = "AdoptionPrefs";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_cat);

        // buttons
        Button cleoButton = findViewById(R.id.hiddenCleo);
        Button dukeButton = findViewById(R.id.hiddenDuke);
        Button blueButton = findViewById(R.id.hiddenBlue);
        Button spencerButton = findViewById(R.id.hiddenSpencer);
        Button chloeButton = findViewById(R.id.hiddenChloe);

        //text
        TextView cleoText = findViewById(R.id.cleotxt);
        TextView dukeText = findViewById(R.id.duketxt);
        TextView blueText = findViewById(R.id.bluetxt);
        TextView spencerText = findViewById(R.id.spencertxt);
        TextView chloeText = findViewById(R.id.chloetxt);

        //same lang sa dog maem
        // nag dagdag ako textView sa xml

        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        if (preferences.getBoolean("Cleo_adopted", false)) {
            cleoButton.setEnabled(false);
            cleoText.setText("Already Adopt");
        }
        if (preferences.getBoolean("Duke_adopted", false)) {
            dukeButton.setEnabled(false);
            dukeText.setText("Already Adopt");
        }
        if (preferences.getBoolean("Blue_adopted", false)) {
            blueButton.setEnabled(false);
            blueText.setText("Already Adopt");
        }
        if (preferences.getBoolean("Spencer_adopted", false)) {
            spencerButton.setEnabled(false);
            spencerText.setText("Already Adopt");
        }
        if (preferences.getBoolean("Chloe_adopted", false)) {
            chloeButton.setEnabled(false);
            chloeText.setText("Already Adopt");
        }

        cleoButton.setOnClickListener(v -> {
            if (cleoButton.isEnabled()) {
                navigateToAdopterForm("Cat", "Cleo");
            }
        });

        dukeButton.setOnClickListener(v -> {
            if (dukeButton.isEnabled()) {
                navigateToAdopterForm("Cat", "Duke");
            }
        });

        blueButton.setOnClickListener(v -> {
            if (blueButton.isEnabled()) {
                navigateToAdopterForm("Cat", "Blue");
            }
        });

        spencerButton.setOnClickListener(v -> {
            if (spencerButton.isEnabled()) {
                navigateToAdopterForm("Cat", "Spencer");
            }
        });

        chloeButton.setOnClickListener(v -> {
            if (chloeButton.isEnabled()) {
                navigateToAdopterForm("Cat", "Chloe");
            }
        });

    }

    private void navigateToAdopterForm(String petType, String petName) {
        Intent intent = new Intent(this, infoframe.class);
        intent.putExtra("PetType", petType);
        intent.putExtra("Animal", petName);
        startActivity(intent);
    }
}


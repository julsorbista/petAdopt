package com.example.adoptp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class showDog extends AppCompatActivity {

    private static final String PREFS_NAME = "AdoptionPrefs";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_dog);

        // buttons
        Button cooperButton = findViewById(R.id.hiddenCooper);
        Button bucketButton = findViewById(R.id.hiddenBucket);
        Button gidgetButton = findViewById(R.id.hiddenGidget);
        Button chaseButton = findViewById(R.id.hiddenChase);
        Button chickenButton = findViewById(R.id.hiddenChicken);

        //text
        TextView cooperText = findViewById(R.id.coopertxt);
        TextView bucketText = findViewById(R.id.buckettxt);
        TextView gidgetText = findViewById(R.id.gidettxt);
        TextView chaseText = findViewById(R.id.chasetxt);
        TextView chickenText = findViewById(R.id.chickentxt);

        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);


        // isahan lang siya ma aadopt kasi na auto save siya sa prederences
        if (preferences.getBoolean("Cooper_adopted", false)) {
            bucketButton.setEnabled(false);
            bucketText.setText("Already Adopted"); // ito dinagdag ko
        }

        if (preferences.getBoolean("Bucket_adopted", false)) {
            bucketButton.setEnabled(false);
            bucketText.setText("Already Adopted");
        }


        if (preferences.getBoolean("Gidget_adopted", false)) {
            gidgetButton.setEnabled(false);
            gidgetText.setText("Already Adopted");
        }

        if (preferences.getBoolean("Chase_adopted", false)) {
            chaseButton.setEnabled(false);
            chaseText.setText("Already Adopted");
        }

        if (preferences.getBoolean("Chicken_adopted", false)){
            chickenButton.setEnabled(false);
            chickenText.setText("Already Adopted");
        }

        // Set up button click listeners
        cooperButton.setOnClickListener(v -> {
            if (cooperButton.isEnabled()) {
                navigateToAdopterForm("Dog", "Cooper");
            } // inalis ko lang yung else na toast
        });

       bucketButton.setOnClickListener(v -> {
           if (bucketButton.isEnabled()) {
               navigateToAdopterForm("Dog", "Bucket");
           }
       });

        gidgetButton.setOnClickListener(v -> {
            if (gidgetButton.isEnabled()) {
                navigateToAdopterForm("Dog", "Gidget");
            }
        });

        chaseButton.setOnClickListener(v -> {
            if (chaseButton.isEnabled()) {
                navigateToAdopterForm("Dog", "Chase");
            }
        });


        chickenButton.setOnClickListener(v -> {
            if (chickenButton.isEnabled()){
                navigateToAdopterForm("Dog", "Chicken");
            }
        });
    }

    private void navigateToAdopterForm(String petType, String petName) {
        Intent intent = new Intent(this, infoframe.class);
        intent.putExtra("PetType", petType);
        intent.putExtra("Animal", petName);
        startActivity(intent);
    }
}

// nag dagdag ako textView sa xml
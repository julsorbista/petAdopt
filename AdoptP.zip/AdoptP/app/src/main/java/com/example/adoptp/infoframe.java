package com.example.adoptp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.InputFilter;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class infoframe extends AppCompatActivity {

    private static final String PREFS_NAME = "AdoptionPrefs"; //stores the adoption status

    public ArrayList<String> userInputs = new ArrayList<>();// araylist para mastore yung user input papunta sa slip
    public static final long START_TIME_IN_MILLIS = 5000; // timer lang maem

    // sa daet maem
    private final List<String> unavailableDates = Arrays.asList("03/04/2025", "03/14/2025", "03/17/2025", "03/20/2025", "03/25/2025", "03/31/2025");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_infoframe);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Views initialization
        TextView Rname = findViewById(R.id.Rname);
        TextView Rnum = findViewById(R.id.Rnum);
        TextView Rdate = findViewById(R.id.Rdate);
        TextView Aname = findViewById(R.id.animalname);
        TextView tpdog = findViewById(R.id.dogtxt);
        TextView tpcat = findViewById(R.id.cattxt);
        EditText uname = findViewById(R.id.nametxt);
        EditText unum = findViewById(R.id.numtxt);
        EditText address = findViewById(R.id.addtext);
        EditText occp = findViewById(R.id.occupttxt);
        EditText udate = findViewById(R.id.datetxt);
        Button adopt = findViewById(R.id.adoptbtn);
        CardView card = findViewById(R.id.cardrep);

        //code sa date para ma allow yung numbers tas "/"
        InputFilter filter = (source, start, end, dest, dstart, dend) -> source.toString().matches("[0-9/]*") ? null : "";
        udate.setFilters(new InputFilter[]{filter});

        // get pet name passed from previous activity
        Intent intent = getIntent();
        String petName = intent.getStringExtra("Animal");

        // pang display dun sa 'Type of Pet' kung dog or cat ba
        List<String> dogs = Arrays.asList("Cooper", "Bucket", "Gidget", "Chase", "Chicken");
        List<String> cats = Arrays.asList("Cleo", "Duke", "Blue", "Chloe", "Spencer");

        if (dogs.contains(petName)) {
            tpdog.setText("Dog");
        } else if (cats.contains(petName)) {
            tpcat.setText("Cat");
        }

        // SharedPreferences sa adoption status
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        if (preferences.getBoolean(petName + "_adopted", false)) {
            adopt.setEnabled(false); // pang disable dun sa button pag na adopt na siya
            adopt.setText("Adopted");
        }


        adopt.setOnClickListener(view -> {
            if (uname.getText().toString().isEmpty() || unum.getText().toString().isEmpty() || address.getText().toString().isEmpty() ||
                    occp.getText().toString().isEmpty() || udate.getText().toString().isEmpty()) {
                Toast.makeText(this, "Please Complete the Information First", Toast.LENGTH_LONG).show();
                return;
            }

            String dateInput = udate.getText().toString();

            // pang check if date is unavailable
            if (unavailableDates.contains(dateInput)) {
                Toast.makeText(this, "Oops! This date is reserved for an event!", Toast.LENGTH_LONG).show();
                return;
            }

            // save the adoption status
            saveAdoptionStatus(petName);

            // // pang display dun sa slip with user details
            if (card.getVisibility() == View.GONE) {
                card.setVisibility(View.VISIBLE);
                userInputs.add(uname.getText().toString());
                userInputs.add(unum.getText().toString());
                userInputs.add(dateInput);
                Rname.setText(userInputs.get(0));
                Rnum.setText(userInputs.get(1));
                Rdate.setText(userInputs.get(2));
                Aname.setText(petName);
                startCountdown();
            } else {
                card.setVisibility(View.GONE);
            }
        });
    }

    // save adoption state sa SharedPreferences
    private void saveAdoptionStatus(String petName) {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(petName + "_adopted", true);
        editor.apply();
    }

    // para sa countdown po ito maem
    private void startCountdown() {
        new CountDownTimer(START_TIME_IN_MILLIS, 5000) {
            @Override
            public void onTick(long millisUntilFinished) {}

            @Override
            public void onFinish() {
                Intent intent = new Intent(infoframe.this, mainmenu.class);
                startActivity(intent);
                finish();
            }
        }.start();
    }
}
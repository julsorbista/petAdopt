package com.example.adoptp;

import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button login = findViewById(R.id.loginbtn); // login button
        TextView create = findViewById(R.id.accbtn); // text button
        create.setPaintFlags(create.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG); // underline text
        EditText usernamelog = findViewById(R.id.unamelog);
        EditText passwordlog = findViewById(R.id.passlog);

        login.setOnClickListener(view -> {
            String uname = usernamelog.getText().toString();
            String password = passwordlog.getText().toString();

            if (uname.isEmpty() && password.isEmpty()) {
                Toast.makeText(getApplicationContext(), "Please enter username and password.", Toast.LENGTH_LONG).show();
                return;
            } else if (uname.isEmpty()) {
                Toast.makeText(getApplicationContext(), "Please enter username.", Toast.LENGTH_LONG).show();
                return;
            } else if (password.isEmpty()) {
                Toast.makeText(getApplicationContext(), "Please enter password.", Toast.LENGTH_LONG).show();
                return;
            }

            // Check if the username and password kung same sa register
            boolean userFound = false;
            for (String[] user : registerpage.useraccount) { // users yan yung arraylist dun sa register
                if (user[0].equals(uname) && user[1].equals(password)) { // Compare with the value of name and password
                    userFound = true;
                    break;
                }
            }

            if (userFound) { // already have account ito
                Toast.makeText(getApplicationContext(), "Login successful!", Toast.LENGTH_LONG).show();
                Toast.makeText(getApplicationContext(), "Registration successful!", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(login.this, mainmenu.class);
                startActivity(intent);
            } else { // wala pa account need pa sign up
                Toast.makeText(getApplicationContext(), "You don’t have an account. Please sign up.", Toast.LENGTH_LONG).show();
            }
        });


        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(login.this, registerpage.class));
            }
        });

    }
}
package com.example.adoptp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.ImageView;
import android.widget.RelativeLayout;  // Import RelativeLayout for layout management

import androidx.fragment.app.Fragment;

public class donateFragment extends Fragment {

    private ImageView organizationImage1;

    private ImageView organizationImage2;

    private ImageView organizationImage3;
    private ImageView organizationImage4;

    private EditText editTextAmount;
    private Button buttonDonate1;

    private Button buttonDonate2;
    private Button buttonDonate3;
    private Button buttonDonate4;
    private Button btnSubmitDonation;
    private LinearLayout donationLayout;
    private RelativeLayout Layout1;
    private RelativeLayout Layout2;
    private RelativeLayout Layout3;
    private RelativeLayout Layout4;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_donate, container, false);

        organizationImage1 = view.findViewById(R.id.orgImage1);
        organizationImage2 = view.findViewById(R.id.orgImage2);
        organizationImage3 = view.findViewById(R.id.orgImage3);
        organizationImage4 = view.findViewById(R.id.orgImage4);
        editTextAmount = view.findViewById(R.id.editTextAmount);
        buttonDonate1 = view.findViewById(R.id.btnDonate1);
        buttonDonate2 = view.findViewById(R.id.btnDonate2);
        buttonDonate3 = view.findViewById(R.id.btnDonate3);
        buttonDonate4 = view.findViewById(R.id.btnDonate4);
        btnSubmitDonation = view.findViewById(R.id.btnSubmitDonation);
        donationLayout = view.findViewById(R.id.donationLayout);
        Layout1 = view.findViewById(R.id.orgLayout1);
        Layout2 = view.findViewById(R.id.orgLayout2);//
        Layout3 = view.findViewById(R.id.orgLayout3);
        Layout4 = view.findViewById(R.id.orgLayout4);
        organizationImage1.setImageResource(R.drawable.d1);
        organizationImage2.setImageResource(R.drawable.d2);
        organizationImage3.setImageResource(R.drawable.d3);
        organizationImage4.setImageResource(R.drawable.d4);

        donationLayout.setVisibility(View.GONE);

        buttonDonate1.setOnClickListener(v -> {
            // para mahide yung org tyaka donate button
            organizationImage1.setImageResource(R.drawable.d1);
            Layout2.setVisibility(View.GONE); // success
            Layout3.setVisibility(View.GONE);
            Layout4.setVisibility(View.GONE);
            buttonDonate1.setVisibility(View.GONE);

            // para mag pakita yung frame ng enter donation tyaka submit button
            donationLayout.setVisibility(View.VISIBLE);
        });

        buttonDonate2.setOnClickListener(v -> {
            organizationImage2.setImageResource(R.drawable.d2); // Image for organization 2
            Layout1.setVisibility(View.GONE);
            Layout3.setVisibility(View.GONE);
            Layout4.setVisibility(View.GONE);
            buttonDonate2.setVisibility(View.GONE);
            donationLayout.setVisibility(View.VISIBLE);
        });

        buttonDonate3.setOnClickListener(v -> {
            organizationImage3.setImageResource(R.drawable.d3); // Image for organization 2 // 3 na dapat baks
            Layout1.setVisibility(View.GONE); //wait
            Layout2.setVisibility(View.GONE);
            Layout4.setVisibility(View.GONE);
            buttonDonate3.setVisibility(View.GONE);
            donationLayout.setVisibility(View.VISIBLE);
        });

        buttonDonate4.setOnClickListener(v -> {
            organizationImage4.setImageResource(R.drawable.d4); // Image for organization 2 // 4 ma dapat baks
            Layout1.setVisibility(View.GONE);
            Layout2.setVisibility(View.GONE);
            Layout3.setVisibility(View.GONE);
            buttonDonate4.setVisibility(View.GONE);
            donationLayout.setVisibility(View.VISIBLE);
        });

        btnSubmitDonation.setOnClickListener(v -> {
            String amountText = editTextAmount.getText().toString();

            if (amountText.isEmpty()) {
                Toast.makeText(getContext(), "Please enter an amount", Toast.LENGTH_SHORT).show();
            } else {
                try {
                    double amount = Double.parseDouble(amountText);
                    if (amount > 0) {
                        Toast.makeText(getContext(), "You have successfully donated " + amount + "!", Toast.LENGTH_LONG).show();
                        editTextAmount.setText(""); // para maclear yung edi text dialog
                        donationLayout.setVisibility(View.GONE); // para bumalik sa frame ng lists of ORGS
                        Layout1.setVisibility(View.VISIBLE);
                        Layout2.setVisibility(View.VISIBLE);
                        Layout3.setVisibility(View.VISIBLE);
                        Layout4.setVisibility(View.VISIBLE);// para makita yung org pics
                        buttonDonate1.setVisibility(View.VISIBLE);
                        buttonDonate2.setVisibility(View.VISIBLE);
                        buttonDonate3.setVisibility(View.VISIBLE);
                        buttonDonate4.setVisibility(View.VISIBLE);// para makita yung donate button
                    } else {
                        Toast.makeText(getContext(), "Donation amount must be greater than 0.", Toast.LENGTH_LONG).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(getContext(), "Please enter a valid number.", Toast.LENGTH_LONG).show();
                }
            }
        });

        return view;
    }
}